# FileTools — PDF/Word/Excel Converter Website

एक असली, working file-conversion website: PDF↔Word, Image→Word, Image→Excel।

## यह क्यों server चाहता है (सिर्फ website hosting काफी नहीं है)

ये conversions सिर्फ browser की JavaScript से ठीक तरह से नहीं हो सकते —
इनके लिए असली software libraries चाहिए होती हैं:

| Tool | असल में क्या इस्तेमाल होता है |
|---|---|
| PDF → Word | Python library `pdf2docx` |
| Word → PDF | `LibreOffice` (system software) |
| Image → Word | `Tesseract OCR` (text पहचानने वाला engine) |
| Image → Excel | `Tesseract OCR` + column detection |
| PDF Compress | `Ghostscript` (system software) |

इसलिए साधारण shared hosting (जैसे सिर्फ HTML files upload करने वाली hosting)
पर यह नहीं चलेगा — आपको एक ऐसी hosting चाहिए जहाँ Python code और system
software (LibreOffice, Tesseract) install हो सकें।

## Hosting के आसान विकल्प (कोई सर्वर न होने पर)

1. **Render.com** — Docker deploy का free/paid tier support करता है, सबसे आसान।
2. **Railway.app** — Docker-friendly, शुरुआत के लिए अच्छा।
3. **VPS** (DigitalOcean, Hostinger VPS, AWS Lightsail) — पूरा control, ~$5-6/month से शुरू।

नीचे दोनों तरीकों के steps दिए हैं।

---

## तरीका A: Render.com पर Docker से Deploy (सबसे आसान)

1. इस पूरे folder को GitHub पर एक नई repository में upload करें।
2. [render.com](https://render.com) पर account बनाएं → **New + → Web Service**।
3. अपनी GitHub repo select करें।
4. Render अपने आप `Dockerfile` पहचान लेगा — Environment: **Docker** चुनें।
5. Deploy दबाएं। कुछ मिनट में आपकी website live हो जाएगी
   (LibreOffice + Tesseract अपने आप install हो जाएंगे, Dockerfile में लिखे हैं)।

## तरीका B: अपने VPS (Ubuntu) पर Deploy

```bash
# 1) Server पर जरूरी चीज़ें install करें
sudo apt update
sudo apt install -y python3-pip python3-venv libreoffice tesseract-ocr tesseract-ocr-hin ghostscript nginx

# 2) कोड को server पर upload करें (git clone या scp से), फिर:
cd filetools
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3) Test run करें
python app.py
# अब http://<server-ip>:5000 पर खुलेगा

# 4) Production के लिए gunicorn + nginx (recommended)
gunicorn -w 2 -b 0.0.0.0:5000 --timeout 120 app:app
```

फिर अपने domain को nginx से server के port 5000 पर reverse-proxy करें,
और free SSL के लिए `certbot` इस्तेमाल करें।

---

## Local पर test करना (development)

```bash
cd filetools
python3 -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
फिर browser में खोलें: **http://localhost:5000**

⚠️ Local Windows पर बिना LibreOffice install किए "Word to PDF" काम नहीं करेगा,
और बिना Tesseract install किए Image tools काम नहीं करेंगे। Docker तरीका इस्तेमाल
करना सबसे सरल है क्योंकि सब कुछ अपने आप install हो जाता है।

## Limits / आगे बढ़ाने के सुझाव

- अभी हर file की max size 25MB रखी है (`app.py` में `MAX_FILE_SIZE_MB` बदल सकते हैं)।
- Image → Excel में column detection एक basic heuristic (2+ spaces = नया column) पर
  आधारित है — साफ़ tables पर अच्छा result देता है, बहुत complex tables पर manual
  सुधार की जरूरत पड़ सकती है।
- Business के लिए आगे जोड़ने लायक चीज़ें: उपयोगकर्ता login, daily conversion limit
  (free vs paid plan), payment gateway (Razorpay/Stripe), और भाषा बदलने का option।

---

## SEO — Google Search में दिखने के लिए (traffic बढ़ाने के लिए)

### 1. Code में क्या पहले से तैयार है

हर tool का अपना अलग URL है ताकि Google हर keyword के लिए सही page दिखा सके:

- `/pdf-to-word`, `/word-to-pdf`, `/pdf-compress`, `/image-to-word`, `/image-to-excel`
- Size-specific pages (बहुत ज़्यादा search होती हैं भारत में exam/job forms के लिए):
  `/compress-pdf-to-100kb`, `/compress-pdf-to-200kb`, `/compress-pdf-to-500kb`, `/compress-pdf-to-1mb`

हर page में अपने आप ये चीज़ें भी लगी हैं:
- अलग `<title>` और meta description (हर page अलग keyword target करता है)
- Schema.org structured data (`SoftwareApplication` + `FAQPage`) — इससे Google कभी-कभी
  आपके page को rich result/FAQ के साथ दिखाता है
- `/sitemap.xml` और `/robots.txt` — Google को बताते हैं कि कौन-कौन से pages crawl करें

**ज़रूरी:** Deploy करने के बाद `seo_content.py` में सबसे ऊपर `SITE_URL` को अपने
असली domain से बदलें (जैसे `https://filetools.in`), वरना sitemap और canonical URLs
गलत बनेंगे।

नया keyword target करना हो (जैसे "compress pdf to 50kb" या "jpg to pdf"), तो बस
`seo_content.py` में एक नई entry जोड़ें — page अपने आप बन जाएगा और sitemap में
अपने आप जुड़ जाएगा।

### 2. Deploy के बाद ये ज़रूर करें (code के बाहर का काम)

1. **Google Search Console** (search.google.com/search-console) पर अपनी site add करें,
   domain verify करें, फिर अपनी sitemap URL (`https://आपकाdomain.com/sitemap.xml`)
   submit करें। इससे Google को नए pages जल्दी मिलते हैं।
2. **Bing Webmaster Tools** पर भी वैसा ही करें (कुछ traffic Bing से भी आता है)।
3. Har page को असली users से पहले खुद Google पर search करके देखें — जैसे
   "pdf to word converter free" — देखें कि आपके competitors के pages में क्या content है,
   और अपने page पर उससे थोड़ा बेहतर/detailed content डालें (जितना ज़्यादा useful text
   page पर होगा, उतना बेहतर rank करेगा — सिर्फ tool काफी नहीं, साथ में समझाने वाला
   content भी चाहिए, जो अभी हर page पर intro + FAQ के रूप में है)।
4. **Backlinks** — अपनी site का link किसी relevant जगह share करें: Quora जवाबों में
   (जहाँ लोग "pdf ko word me kaise badle" पूछते हैं), Reddit, WhatsApp/Telegram groups,
   या किसी blog पर guest post में। Backlinks Google ranking का बड़ा factor हैं।
5. **Page speed** — Google mobile-friendly और तेज़ loading वाले pages को ऊपर रखता है।
   [PageSpeed Insights](https://pagespeed.web.dev) पर अपनी site test करें।
6. Ranking में समय लगता है — नई website को Google में अच्छी position पाने में
   आमतौर पर 2-6 महीने लगते हैं, खासकर competitive keywords ("pdf to word") के लिए।
   Size-specific pages ("compress pdf to 100kb") पर competition कम है, वहाँ जल्दी
   result दिख सकता है।

### 3. आगे और keywords जोड़ने का सुझाव

अभी सिर्फ PDF compress के size-specific pages बनाए हैं। इसी pattern पर आप आगे ये भी
जोड़ सकते हैं (हर एक अलग search-volume वाला keyword है):
- `/jpg-to-pdf`, `/pdf-to-jpg` — बहुत ज़्यादा search होते हैं
- `/merge-pdf`, `/split-pdf`
- `/compress-image-to-50kb` (photo के लिए, जैसे passport size photo upload फॉर्म्स में)

हर एक के लिए `seo_content.py` में entry और `app.py` में conversion logic जोड़नी होगी।

