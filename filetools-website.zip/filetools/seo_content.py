"""
हर page का SEO content यहाँ रखा गया है — ताकि हर URL Google पर अलग
keyword के लिए rank कर सके (जैसे "pdf to word", "compress pdf to 100kb")।

नया tool/landing-page जोड़ना हो तो बस यहाँ एक entry जोड़ें,
app.py अपने आप उसके लिए route और sitemap entry बना देगा।
"""

SITE_NAME = "FileTools"
SITE_URL = "https://your-domain.com"  # <-- Deploy करने के बाद अपना असली domain डालें

TOOLS = {

    "pdf-to-word": {
        "endpoint": "/api/pdf-to-word",
        "accept": ".pdf",
        "outname": "converted.docx",
        "icon": "📕➡️📘",
        "button_text": "Convert करें",
        "title": "PDF to Word Converter Online Free — बिना Software के | FileTools",
        "meta_description": "PDF को Word (.docx) में मुफ़्त और तेज़ी से convert करें। कोई software install करने की ज़रूरत नहीं, बस file upload करें और download करें।",
        "h1": "PDF to Word Converter",
        "intro": "अपनी PDF फ़ाइल को कुछ ही सेकंड में editable Word document (.docx) में बदलें। Formatting, tables और images जितना हो सके वैसा ही रखा जाता है।",
        "faq": [
            ("क्या यह tool मुफ़्त है?", "हां, PDF to Word convert करना पूरी तरह मुफ़्त है।"),
            ("क्या मेरी file safe रहती है?", "Convert होने के तुरंत बाद server से आपकी file अपने आप delete हो जाती है।"),
            ("क्या scanned PDF भी convert होगी?", "यह tool text-based PDF के लिए सबसे अच्छा काम करता है। Scanned/image PDF के लिए हमारा Image to Word tool इस्तेमाल करें।"),
        ],
    },

    "word-to-pdf": {
        "endpoint": "/api/word-to-pdf",
        "accept": ".doc,.docx",
        "outname": "converted.pdf",
        "icon": "📘➡️📕",
        "button_text": "Convert करें",
        "title": "Word to PDF Converter Online Free — DOC/DOCX से PDF | FileTools",
        "meta_description": "Word document (.doc/.docx) को एक क्लिक में PDF में convert करें। मुफ़्त, तेज़ और बिना किसी software के।",
        "h1": "Word to PDF Converter",
        "intro": "अपनी Word file को professional PDF में बदलें — resume, assignment, letter या कोई भी document, formatting बिल्कुल वैसी ही रहती है।",
        "faq": [
            ("क्या .doc और .docx दोनों चलेंगे?", "हां, दोनों formats support करते हैं।"),
            ("PDF की quality कैसी रहेगी?", "Original Word document जैसी ही formatting और quality के साथ PDF बनती है।"),
        ],
    },

    "pdf-compress": {
        "endpoint": "/api/pdf-compress",
        "accept": ".pdf",
        "outname": "compressed.pdf",
        "icon": "📕⬇️",
        "button_text": "Compress करें",
        "has_quality": True,
        "has_target_kb": True,
        "title": "PDF Compress Online Free — PDF Size कम करें | FileTools",
        "meta_description": "PDF की size कम करें बिना quality ज़्यादा खराब किए। Exact target size (जैसे 100KB, 200KB, 500KB) तक compress करने का option भी उपलब्ध है।",
        "h1": "PDF Compress — PDF Size कम करें",
        "intro": "बड़ी PDF file को छोटा करें — email attach करने के लिए, form upload करने के लिए, या storage बचाने के लिए। नीचे जितना size चाहिए वो डालें या quality preset चुनें।",
        "faq": [
            ("क्या मैं exact size (जैसे 100KB) तक compress कर सकता हूं?", "हां, 'Target Size' box में KB में size डालें, tool अपने आप उतने या उससे कम size तक compress करने की कोशिश करेगा।"),
            ("क्या compression से PDF खराब हो जाएगी?", "जितना ज़्यादा compress करेंगे, images की quality उतनी कम होगी, पर text हमेशा साफ़ रहता है।"),
        ],
    },

    "image-to-word": {
        "endpoint": "/api/image-to-word",
        "accept": ".png,.jpg,.jpeg,.webp,.bmp",
        "outname": "extracted.docx",
        "icon": "🖼️➡️📘",
        "button_text": "Convert करें",
        "title": "Image to Word Converter Online — Photo से Text निकालें | FileTools",
        "meta_description": "किसी भी photo या scanned image में लिखा टेक्स्ट (OCR) निकालकर editable Word document बनाएं। Hindi और English दोनों support करता है।",
        "h1": "Image to Word (OCR)",
        "intro": "Photo, scan या screenshot में लिखे टेक्स्ट को automatically पहचानकर एक editable Word file बनाएं — Hindi और English दोनों भाषाओं में।",
        "faq": [
            ("कौन सी भाषाएं support होती हैं?", "अभी Hindi और English text पहचाना जाता है।"),
            ("क्या हाथ से लिखा (handwriting) टेक्स्ट भी पढ़ लेगा?", "यह tool printed/typed text के लिए सबसे सटीक है, handwriting पर result कम सटीक हो सकता है।"),
        ],
    },

    "image-to-excel": {
        "endpoint": "/api/image-to-excel",
        "accept": ".png,.jpg,.jpeg,.webp,.bmp",
        "outname": "extracted.xlsx",
        "icon": "🖼️➡️📗",
        "button_text": "Convert करें",
        "title": "Image to Excel Converter Online — Table Photo से Excel बनाएं | FileTools",
        "meta_description": "Table या data की photo से सीधे Excel (.xlsx) फ़ाइल बनाएं। Rows और columns अपने आप पहचाने जाते हैं।",
        "h1": "Image to Excel (OCR)",
        "intro": "किसी table, list या data की फोटो अपलोड करें — हम उसमें से टेक्स्ट पहचानकर rows/columns में arrange की हुई Excel file बना देंगे।",
        "faq": [
            ("क्या complex tables अच्छे से बनेंगी?", "साफ़, सीधी tables पर सबसे अच्छा result मिलता है। बहुत complex/merged-cell tables में manual सुधार लग सकता है।"),
        ],
    },
}


# ------------------------------------------------------------------
# "Compress PDF to X KB" जैसे बहुत ज़्यादा search होने वाले exact-size
# pages — भारत में exam/job forms के लिए ये बहुत search होते हैं
# (जैसे "compress pdf to 100kb for SSC form")
# ------------------------------------------------------------------

COMPRESS_SIZE_PAGES = {

    "compress-pdf-to-100kb": {
        "target_kb": 100,
        "title": "Compress PDF to 100KB Online Free | FileTools",
        "meta_description": "PDF file को 100KB या उससे कम size में compress करें — exam form, job application या online upload के लिए।",
        "h1": "PDF को 100KB तक Compress करें",
        "intro": "बहुत सारे government/exam forms में PDF की size 100KB से कम होनी ज़रूरी होती है (जैसे SSC, Railway, Police भर्ती फॉर्म)। यह tool आपकी PDF को automatically 100KB या उससे कम में compress करने की कोशिश करता है।",
    },
    "compress-pdf-to-200kb": {
        "target_kb": 200,
        "title": "Compress PDF to 200KB Online Free | FileTools",
        "meta_description": "PDF file को 200KB या उससे कम size में compress करें — किसी भी form या application के लिए।",
        "h1": "PDF को 200KB तक Compress करें",
        "intro": "कई online forms में document size 200KB तक limit रहती है। अपनी PDF यहां डालें, tool अपने आप उसे 200KB या उससे कम में compress करने की कोशिश करेगा।",
    },
    "compress-pdf-to-500kb": {
        "target_kb": 500,
        "title": "Compress PDF to 500KB Online Free | FileTools",
        "meta_description": "PDF file को 500KB या उससे कम size में compress करें — email attachment या upload के लिए।",
        "h1": "PDF को 500KB तक Compress करें",
        "intro": "Email attachment limits या upload restrictions के लिए अपनी PDF को 500KB या उससे कम तक compress करें, बिना ज़्यादा quality खोए।",
    },
    "compress-pdf-to-1mb": {
        "target_kb": 1024,
        "title": "Compress PDF to 1MB Online Free | FileTools",
        "meta_description": "बड़ी PDF file को 1MB या उससे कम size में compress करें — तेज़ी से share और upload करने के लिए।",
        "h1": "PDF को 1MB तक Compress करें",
        "intro": "बड़ी PDF files भेजने/upload करने में दिक्कत होती है। इसे 1MB या उससे कम तक compress करें ताकि आसानी से share हो सके।",
    },
}
